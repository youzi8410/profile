var addevent = document.getElementsByClassName('add_icon')[0];
var addinput = document.getElementsByClassName('add_input')[0];
var todo = document.getElementsByClassName('todo')[0];
var done = document.getElementsByClassName('done')[0];
var controlModify=true;                                    //控制修改內文

//點擊事件
addevent.onclick=function(){
  var addcontent = addinput.value.trim();
  if(addcontent == ""){                                    //不能為空值
    alert("請輸入文字!!");
  }else{
    addtodoitem(addcontent);                               //不為空值時新增
    addinput.value="";
  }
};

function addtodoitem(content){
  var todoItem = document.createElement("div");            //個別建立區塊
  var todoItemText = document.createElement("div");
  var todoItemIcons = document.createElement("div");
  var todoItemIconsModify = document.createElement("div");
  var todoItemIconsTrash = document.createElement("div");
  var todoItemIconsDone = document.createElement("div");
//新增method
  todoItem.className="todo_item";
  todoItemText.className="todo_item_text";                  //添加文字
  todoItemIcons.className="todo_item_icons";                //添加圖示
  todoItemIconsModify.className="todo_item_icons_modify";   //添加修改圖示
  todoItemIconsTrash.className="todo_item_icons_trash";     //垃圾桶圖示
  todoItemIconsDone.className="todo_item_icons_done";       //勾勾圖示
//添加待辦事項內容
  todoItemText.innerHTML=content;
//添加icon
  todoItemIconsModify.innerHTML="<i class="+'"fas fa-pencil-alt"'+"></i>";
  todoItemIconsTrash.innerHTML="<i class="+'"fas fa-trash-alt"'+"></i>";
  todoItemIconsDone.innerHTML="<i class="+'"far fa-check-circle"'+"></i>";
//append圖示在內文後
  todoItemIcons.appendChild(todoItemIconsModify);
  todoItemIcons.appendChild(todoItemIconsTrash);
  todoItemIcons.appendChild(todoItemIconsDone);
  todoItem.appendChild(todoItemText);
  todoItem.appendChild(todoItemIcons);
//添加到頁面上
  todo.appendChild(todoItem);
//修改method
  todoItemIconsModify.onclick=function(ev){
    if (controlModify==true){
      controlModify=false;
      var todoItemBefore=todoItemText.innerHTML;
      todoItemText.innerHTML="<input class="+'"todo_item_text_input"'+'type="text">';
      var todoItemTextInput = document.getElementsByClassName('todo_item_text_input')[0];
      todoItemTextInput.value= todoItemBefore;
      todoItemTextInput.focus();                                                //focus在打字區
      ev=window.event || ev;
      ev.stopPropagation ? ev.stopPropagation() : ev.cancelBubble=true;         //離開keyin區時結束
      document.onclick=function(){
        todoItemText.innerHTML=todoItemTextInput.value;
        controlModify=true;
      }
    }
  }
  //刪除method
  todoItemIconsTrash.onclick=function(){
    todoItem.parentNode.removeChild(todoItem);
  }
  //完成method
  todoItemIconsDone.onclick=function(){
    if(controlModify==true){
      addDoneItem(todoItemText.innerHTML);
      todoItem.parentNode.removeChild(todoItem);
    }
  }
}

function addDoneItem(doneContent){
  var doneItem = document.createElement("div");            //個別建立區塊
  var doneItemText = document.createElement("div");
  var doneItemIcons = document.createElement("div");
  var doneItemIconsTrash = document.createElement("div");
  var doneItemIconsDone = document.createElement("div");
  //已完成項目
  doneItem.className="done_item";
  doneItemText.className="done_item_text";
  doneItemIcons.className="done_item_icons";
  doneItemIconsTrash.className="done_item_icons_trash";
  doneItemIconsDone.className="done_item_icons_done";
  //內文
  doneItemText.innerHTML=doneContent;
  //添加圖示
  doneItemIconsTrash.innerHTML="<i class="+'"fas fa-trash-alt"'+"></i>";
  doneItemIconsDone.innerHTML="<i class="+'"fas fa-check-circle"'+"></i>";
  //append圖示在內文後
  doneItemIcons.appendChild(doneItemIconsTrash);
  doneItemIcons.appendChild(doneItemIconsDone);
  doneItem.appendChild(doneItemText);
  doneItem.appendChild(doneItemIcons);
  //添加到頁面上
  done.appendChild(doneItem);
  //刪除method
  doneItemIconsTrash.onclick=function(){
    doneItem.parentNode.removeChild(doneItem);
  }
  // 從已完成列刪除,添加到未完成列
  doneItemIconsDone.onclick=function(){
    addtodoitem(doneItemText.innerHTML);
    doneItem.parentNode.removeChild(doneItem);
  }
}

